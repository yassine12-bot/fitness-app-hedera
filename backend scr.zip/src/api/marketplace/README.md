# Marketplace Module

**Responsable:** Backend Team + Bouchra (Blockchain)

## Fichiers:
- `products.js` - Gérer les produits
- `purchase.js` - Acheter avec FIT tokens

## Endpoints:
- GET `/api/marketplace/products`
- POST `/api/marketplace/purchase`
