# Workouts Module

**Responsable:** Backend Team

## Fichiers:
- `steps.js` - Enregistrer et tracker les pas

## Endpoints:
- POST `/api/workouts/steps`
- GET `/api/workouts/history`
