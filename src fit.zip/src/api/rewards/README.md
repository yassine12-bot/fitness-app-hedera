# Rewards Module

**Responsable:** Backend Team

## Fichiers:
- `encouragement.js` - +2 FIT pour commentaire positif
- `bestComment.js` - +10 FIT meilleur commentaire
- `referral.js` - +15 FIT parrainage

## Endpoints:
- POST `/api/rewards/encouragement`
- POST `/api/rewards/best-comment`
- POST `/api/rewards/referral`
