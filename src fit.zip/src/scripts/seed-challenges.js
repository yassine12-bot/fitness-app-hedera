require('dotenv').config();
const sqlite3 = require('sqlite3').verbose();
const path = require('path');

/**
 * Seed Challenge Definitions in SQLite
 * 
 * This script:
 * 1. Creates challenges table if not exists
 * 2. Seeds challenge definitions (id, title, type)
 * 3. Blockchain stores target/reward/level (synced later)
 * 
 * Run ONCE after deploying contract
 */

const CHALLENGE_DEFINITIONS = [
  // Daily Steps (1-5)
  { id: 1, title: '1-1 Premier Pas', type: 'daily_steps', category: 'daily' },
  { id: 2, title: '1-2 Randonneur', type: 'daily_steps', category: 'daily' },
  { id: 3, title: '1-3 Marcheur Sérieux', type: 'daily_steps', category: 'daily' },
  { id: 4, title: '1-4 Champion du Jour', type: 'daily_steps', category: 'daily' },
  { id: 5, title: '1-5 Maître du Mouvement', type: 'daily_steps', category: 'daily' },
  
  // Duration Steps (6-10)
  { id: 6, title: '2-1 Début d\'Aventure', type: 'duration_steps', category: 'duration' },
  { id: 7, title: '2-2 Marathonien Débutant', type: 'duration_steps', category: 'duration' },
  { id: 8, title: '2-3 Endurance Pro', type: 'duration_steps', category: 'duration' },
  { id: 9, title: '2-4 Ultra-Marathonien', type: 'duration_steps', category: 'duration' },
  { id: 10, title: '2-5 Légende Vivante', type: 'duration_steps', category: 'duration' },
  
  // Social (11-15)
  { id: 11, title: '3-1 Partage Ton Début', type: 'social', category: 'social' },
  { id: 12, title: '3-2 Ambassadeur', type: 'social', category: 'social' },
  { id: 13, title: '3-3 Influenceur Fitness', type: 'social', category: 'social' },
  { id: 14, title: '3-4 Leader Communautaire', type: 'social', category: 'social' },
  { id: 15, title: '3-5 Icône du Fitness', type: 'social', category: 'social' }
];

async function seedChallenges() {
  console.log('🌱 Seeding Challenge Definitions in SQLite\n');
  console.log('='.repeat(60));

  const dbPath = path.resolve(__dirname, '../fitness.db');
  const db = new sqlite3.Database(dbPath);

  return new Promise((resolve, reject) => {
    db.serialize(() => {
      // Create challenges table
      console.log('\n📊 Creating challenges table...');
      
      db.run(`
        CREATE TABLE IF NOT EXISTS challenges (
          id INTEGER PRIMARY KEY,
          title TEXT NOT NULL,
          type TEXT NOT NULL,
          category TEXT NOT NULL,
          target INTEGER DEFAULT 0,
          reward INTEGER DEFAULT 0,
          level INTEGER DEFAULT 0,
          is_active BOOLEAN DEFAULT 1,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
      `, (err) => {
        if (err) {
          console.error('❌ Error creating table:', err);
          reject(err);
          return;
        }
        console.log('✅ Table created/verified');
      });

      // Clear existing data
      console.log('\n🗑️  Clearing existing challenges...');
      db.run('DELETE FROM challenges', (err) => {
        if (err) console.error('⚠️  Error clearing:', err);
      });

      // Insert challenge definitions
      console.log('\n✨ Inserting challenge definitions...\n');

      const stmt = db.prepare(`
        INSERT INTO challenges (id, title, type, category, target, reward, level, is_active)
        VALUES (?, ?, ?, ?, 0, 0, 0, 1)
      `);

      CHALLENGE_DEFINITIONS.forEach((challenge, index) => {
        stmt.run(
          challenge.id,
          challenge.title,
          challenge.type,
          challenge.category,
          (err) => {
            if (err) {
              console.error(`❌ Error inserting challenge ${challenge.id}:`, err);
            } else {
              console.log(`   ✅ ${challenge.id}. ${challenge.title} (${challenge.type})`);
            }
          }
        );
      });

      stmt.finalize();

      // Verify
      console.log('\n🔍 Verifying...');
      db.all('SELECT id, title, type FROM challenges ORDER BY id', (err, rows) => {
        if (err) {
          console.error('❌ Error verifying:', err);
          reject(err);
          return;
        }

        console.log(`   Found ${rows.length} challenges`);
        
        if (rows.length === 15) {
          console.log('\n✅ SEED COMPLETE!');
          console.log('\n📌 NEXT STEPS:');
          console.log('   1. Sync blockchain data: node scripts/sync-blockchain-data.js');
          console.log('   2. Or login to app (auto-syncs on login)');
          console.log('   3. Blockchain data will populate target/reward/level fields');
        } else {
          console.log('\n⚠️  Warning: Expected 15 challenges, found', rows.length);
        }

        db.close();
        resolve();
      });
    });
  });
}

seedChallenges()
  .then(() => {
    console.log('\n' + '='.repeat(60));
    process.exit(0);
  })
  .catch((error) => {
    console.error('\n❌ Seed failed:', error);
    process.exit(1);
  });